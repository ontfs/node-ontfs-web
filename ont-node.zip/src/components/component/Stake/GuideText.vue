<template>
  <div class="guide-text-class">
    <div class="guide-text-warpper">
      <p class="guide-step guide-normal-text">
        <span class="guide-blod-text">{{data[0].content1}}</span>
        {{data[0].content2}} {{data[0].content3}}
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-img">
        <img class="guide-img-img" :src="data[1].url"/>
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-step guide-normal-text">
        <span class="guide-blod-text">{{data[2].content1}}</span>
        {{data[2].content2}}
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-img">
        <img class="guide-img-img" :src="data[3].url"/>
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-step guide-normal-text">
        <span class="guide-blod-text">{{data[4].content1}}</span>
        {{data[4].content2}}
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-img">
        <img class="guide-img-img" :src="data[5].url"/>
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-step guide-normal-text">
        <span class="guide-blod-text">{{data[6].content1}}</span>
        {{data[6].content2}}
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-note guide-normal-text">
        <span class="guide-blod-text">{{data[7].content1}}</span>
        {{data[7].content2}}
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-img">
        <img class="guide-img-img" :src="data[8].url"/>
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-img">
        <img class="guide-img-img" :src="data[9].url"/>
      </p>
    </div>
    <div class="guide-text-warpper">
      <p class="guide-img">
        <img class="guide-img-img" :src="data[10].url"/>
      </p>
    </div>
  </div>
</template>

<script>
import countTo from 'vue-count-to';
import ProgressNav from './Progress'
import SummaryNav from './Summary'
export default {
  name: "progresss",
  components: { 
    countTo,
    ProgressNav,
    SummaryNav
  },
  props: {
    data: {
      type: Array
    },
  },
  computed: {
    blockAmount() {
        return this.$store.getters.blockstonext || 0;
    },
  },
  data(){
    return{
      startVal:0,
      endVal:0,
    }
  },
  watch:{
    "blockAmount":function(newValue,oldValue){
      this.endVal = newValue
      if ( oldValue == 0 ) {
        this.startVal = newValue
      } else {
        this.startVal = oldValue
      }
    }
  }
};
</script>
<style>
.guide-text-class{
  display: flex;
  justify-content: center;
  flex-flow: column;
}
.guide-text-warpper{
  display: flex;
  justify-content: center;
}
.guide-step{
  width: 552px;
  padding: 16px 24px;
  background:rgba(250,250,250,1);
  margin-bottom: 24px;
  margin-top: 24px;
}
.guide-img{
  width: 552px;
  padding: 16px 24px;
  margin-bottom: 24px;
}
.guide-img-img{
  /* width: 100%; */
  max-height: 300px;
  border:1px solid #000;
}
.guide-note{
  width: 552px;
  padding: 16px 24px;
  background:rgba(72,163,255,0.06);
  margin-bottom: 24px;
  margin-top: 24px;
  text-align: left;
}
.guide-blod-text{
  font-size:14px;
  font-family:NunitoSans;
  font-weight:bold;
  color:rgba(0,0,0,1);
  line-height:19px;
}
.guide-normal-text{
  font-size:14px;
  font-family:NunitoSans;
  font-weight:400;
  color:rgba(0,0,0,1);
  line-height:19px;
  text-align: left;
}
</style>

