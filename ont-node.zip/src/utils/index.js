import map from "./map";

export default {
  map
};
